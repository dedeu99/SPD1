#define _XOPEN_SOURCE 500
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>


int Pid, PidTerminou, Estado;

int main(){
	int state;

	/*while(fork()!=0){
		wait(&state);
	}*/

	exit();



   return(0);
}
